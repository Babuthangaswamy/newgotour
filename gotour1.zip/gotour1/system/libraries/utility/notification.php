<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 *
 * @package    Provab
 * @subpackage Notification
 * @author     Balu A<balu.provab@gmail.com>
 * @version    V1
 */
class Notification {
	public function __construct()
	{

	}
}