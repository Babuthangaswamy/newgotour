<?php

namespace lib;

/**
 * Class LoginLink
 *
 * @package Stripe
 */
class LoginLink extends ApiResource
{

}
