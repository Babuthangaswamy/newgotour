<?php

namespace lib;

/**
 * Class Card
 *
 * @package Stripe
 */
class Card extends ExternalAccount
{

}
