<?php

namespace lib;

/**
 * Class AlipayAccount
 *
 * @package Stripe
 */
class AlipayAccount extends ExternalAccount
{

}
